---
name: Gemini setup access
description: What to do when managed Gemini provisioning is unavailable in this workspace.
---

When managed Gemini integration setup returns an account-upgrade requirement, do not retry it automatically. If the user chooses direct Gemini access, request their key only through the secure Secrets flow and keep it server-side.

**Why:** The managed Gemini setup callback can be unavailable under the current workspace account configuration.

**How to apply:** Respect the user's selected access path. If direct requests are denied or time out, report the provider configuration/access issue clearly rather than claiming AI review works.
