import { desc, eq } from "drizzle-orm";
import {
  canonApprovedAssetsTable,
  canonAuditEventsTable,
  canonFindingsTable,
  canonMembersTable,
  canonReviewsTable,
  canonRulesTable,
  canonRuleVersionsTable,
  canonWorkspacesTable,
  db,
  type CanonMember,
  type CanonWorkspace as CanonWorkspaceRow,
  type CanonWorkspaceSettings,
} from "@workspace/db";

export const defaultCanonRules = [
  {
    id: "VOICE-01",
    type: "Voice",
    text: "Speak with quiet confidence. Prefer clear, direct language over hype or superlatives.",
    owner: "Brand team",
    status: "active" as const,
    expiry: null,
    applies: ["Campaigns", "Social"],
  },
  {
    id: "CLAIM-02",
    type: "Claims",
    text: "Product performance claims must be supported by a current, published source. Claims with expired evidence must not be presented as current.",
    owner: "Legal",
    status: "active" as const,
    expiry: null,
    applies: ["All content"],
  },
  {
    id: "VIS-03",
    type: "Visual identity",
    text: "Do not stretch, recolor, or place the wordmark over visually busy backgrounds. Use only a registered approved logo or wordmark asset.",
    owner: "Design",
    status: "active" as const,
    expiry: null,
    applies: ["Visual"],
  },
  {
    id: "INCL-04",
    type: "Inclusion",
    text: "Use people-first language and avoid assumptions about a reader’s identity or ability.",
    owner: "Brand team",
    status: "active" as const,
    expiry: null,
    applies: ["All content"],
  },
  {
    id: "SOC-05",
    type: "Social",
    text: "Keep social captions useful and specific. Avoid engagement bait and manufactured urgency.",
    owner: "Editorial",
    status: "active" as const,
    expiry: null,
    applies: ["Social"],
  },
  {
    id: "VIS-ALT",
    type: "Accessibility",
    text: "Every visual asset published with content must have meaningful, concise alternative text that describes its purpose or important information.",
    owner: "Accessibility",
    status: "active" as const,
    expiry: null,
    applies: ["Visual", "Digital"],
  },
  {
    id: "VIS-CONTRAST",
    type: "Accessibility",
    text: "Text in digital visual assets should meet WCAG 2.2 AA contrast: at least 4.5:1 for normal text and 3:1 for large text. Automated pixel checks are estimates and require human review for complex backgrounds.",
    owner: "Accessibility",
    status: "active" as const,
    expiry: null,
    applies: ["Visual", "Digital"],
  },
  {
    id: "VIS-LOGO",
    type: "Visual identity",
    text: "A logo, wordmark, or brand icon must match a registered approved asset. Similarity checks flag likely alterations for human confirmation; they do not replace the brand team's approval.",
    owner: "Design",
    status: "active" as const,
    expiry: null,
    applies: ["Visual"],
  },
] as const;

const defaultSettings: CanonWorkspaceSettings = {
  compact: false,
  showTips: true,
  colorMode: "light",
};

export type CanonMemberContext = {
  workspace: CanonWorkspaceRow;
  member: CanonMember;
};

export async function ensureCanonMember(userId: string): Promise<CanonMemberContext> {
  const [existingMember] = await db
    .select()
    .from(canonMembersTable)
    .where(eq(canonMembersTable.userId, userId))
    .limit(1);
  if (existingMember) {
    const [workspace] = await db
      .select()
      .from(canonWorkspacesTable)
      .where(eq(canonWorkspacesTable.id, existingMember.workspaceId))
      .limit(1);
    if (workspace) return { workspace, member: existingMember };
  }

  return db.transaction(async (tx) => {
    const inserted = await tx
      .insert(canonWorkspacesTable)
      .values({ ownerUserId: userId, name: "My CANON workspace" })
      .onConflictDoNothing({ target: canonWorkspacesTable.ownerUserId })
      .returning();
    let workspace = inserted[0];
    if (!workspace) {
      const [existingWorkspace] = await tx
        .select()
        .from(canonWorkspacesTable)
        .where(eq(canonWorkspacesTable.ownerUserId, userId))
        .limit(1);
      workspace = existingWorkspace;
    }
    if (!workspace) throw new Error("Could not initialize the CANON workspace.");

    const insertedMember = await tx
      .insert(canonMembersTable)
      .values({
        workspaceId: workspace.id,
        userId,
        role: "Brand Admin",
        settings: defaultSettings,
      })
      .onConflictDoNothing()
      .returning();
    let member = insertedMember[0];
    if (!member) {
      const [existing] = await tx
        .select()
        .from(canonMembersTable)
        .where(eq(canonMembersTable.userId, userId))
        .limit(1);
      member = existing;
    }
    if (!member) throw new Error("Could not initialize CANON membership.");

    if (inserted[0]) {
      const seedRules = defaultCanonRules.map((rule) => ({
        workspaceId: workspace!.id,
        ruleId: rule.id,
        type: rule.type,
        text: rule.text,
        owner: rule.owner,
        status: rule.status,
        expiry: rule.expiry,
        applies: [...rule.applies],
        version: 1,
        createdBy: userId,
      }));
      await tx.insert(canonRulesTable).values(seedRules);
      await tx.insert(canonRuleVersionsTable).values(
        seedRules.map((rule) => ({
          workspaceId: rule.workspaceId,
          ruleId: rule.ruleId,
          version: 1,
          type: rule.type,
          text: rule.text,
          owner: rule.owner,
          status: rule.status,
          expiry: rule.expiry,
          applies: rule.applies,
          actorUserId: userId,
        })),
      );
      await tx.insert(canonAuditEventsTable).values({
        workspaceId: workspace.id,
        actorUserId: userId,
        actorRole: "Brand Admin",
        action: "Workspace created",
        detail: { ruleCount: seedRules.length },
      });
    }
    return { workspace, member };
  });
}

export async function readCanonWorkspace(userId: string) {
  const { workspace, member } = await ensureCanonMember(userId);
  const [rules, reviews, findings, audit, approvedAssets] = await Promise.all([
    db.select().from(canonRulesTable).where(eq(canonRulesTable.workspaceId, workspace.id)),
    db
      .select()
      .from(canonReviewsTable)
      .where(eq(canonReviewsTable.workspaceId, workspace.id))
      .orderBy(desc(canonReviewsTable.createdAt)),
    db.select().from(canonFindingsTable).where(eq(canonFindingsTable.workspaceId, workspace.id)),
    db
      .select()
      .from(canonAuditEventsTable)
      .where(eq(canonAuditEventsTable.workspaceId, workspace.id))
      .orderBy(desc(canonAuditEventsTable.createdAt))
      .limit(250),
    db
      .select()
      .from(canonApprovedAssetsTable)
      .where(eq(canonApprovedAssetsTable.workspaceId, workspace.id)),
  ]);

  const findingsByReview = new Map<string, typeof findings>();
  const disputesByRule = new Map<string, number>();
  for (const finding of findings) {
    const current = findingsByReview.get(finding.reviewId) ?? [];
    current.push(finding);
    findingsByReview.set(finding.reviewId, current);
    if (finding.creatorStatus === "disputed") {
      disputesByRule.set(finding.ruleId, (disputesByRule.get(finding.ruleId) ?? 0) + 1);
    }
  }

  return {
    id: workspace.id,
    name: workspace.name,
    role: member.role,
    canonicalVersion: workspace.canonicalVersion,
    revision: workspace.revision,
    rules: rules.map((rule) => ({
      id: rule.ruleId,
      type: rule.type,
      text: rule.text,
      owner: rule.owner,
      status: rule.status,
      expiry: rule.expiry,
      applies: rule.applies,
      version: rule.version,
      disputes: disputesByRule.get(rule.ruleId) ?? 0,
    })),
    reviews: reviews.map((review) => ({
      id: review.id,
      title: review.title,
      draft: review.draft,
      summary: review.summary,
      status: review.status,
      attachmentNames: review.attachmentNames,
      canonicalVersion: review.canonicalVersion,
      createdAt: review.createdAt,
      updatedAt: review.updatedAt,
      findings: (findingsByReview.get(review.id) ?? []).map((finding) => ({
        id: finding.id,
        ruleId: finding.ruleId,
        ruleVersion: finding.ruleVersion,
        severity: finding.severity,
        category: finding.category,
        quote: finding.quote,
        suggestion: finding.suggestion,
        explanation: finding.explanation,
        status: finding.creatorStatus,
        reviewerStatus: finding.reviewerStatus,
      })),
    })),
    audit: audit.map((event) => ({
      id: event.id,
      at: event.createdAt,
      action: event.action,
      detail:
        typeof event.detail === "string"
          ? event.detail
          : JSON.stringify(event.detail),
      actor: event.actorRole,
    })),
    approvedAssets: approvedAssets.map((asset) => ({
      id: asset.id,
      label: asset.label,
      fileName: asset.fileName,
      assetType: asset.assetType,
      perceptualHash: asset.perceptualHash,
      createdAt: asset.createdAt,
    })),
    settings: member.settings ?? defaultSettings,
  };
}
