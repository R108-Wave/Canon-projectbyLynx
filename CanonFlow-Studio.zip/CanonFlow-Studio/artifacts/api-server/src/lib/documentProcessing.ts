import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import mammoth from "mammoth";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import sharp from "sharp";
import { createWorker, type Worker } from "tesseract.js";
import { hammingDistance, perceptualHash } from "./perceptualHash";

const require = createRequire(import.meta.url);
const englishIndexPath = require.resolve("@tesseract.js-data/eng");
const englishDataPath = path.join(path.dirname(englishIndexPath), "4.0.0_best_int");
const MAX_DOCUMENT_TEXT = 48_000;
const MAX_IMAGE_PIXELS = 25_000_000;

let ocrWorkerPromise: Promise<Worker> | undefined;

export type UploadedAttachment = {
  fileName: string;
  mimeType: string;
  data: string;
  altText?: string;
  assetType?: "logo" | "wordmark" | "icon" | "other";
};

export type ApprovedAssetReference = {
  id: string;
  label: string;
  assetType: "logo" | "wordmark" | "icon";
  perceptualHash: string;
};

export type AutomaticFinding = {
  ruleId: string;
  severity: "HIGH" | "MEDIUM" | "LOW";
  category: string;
  quote: string;
  suggestion: string;
  explanation: string;
};

export type AttachmentAudit = {
  extractedText: string[];
  findings: AutomaticFinding[];
  notes: string[];
};

export async function processAttachments(
  attachments: UploadedAttachment[],
  approvedAssets: ApprovedAssetReference[],
): Promise<AttachmentAudit> {
  const extractedText: string[] = [];
  const findings: AutomaticFinding[] = [];
  const notes: string[] = [];

  for (const attachment of attachments) {
    const buffer = Buffer.from(attachment.data, "base64");
    if (!buffer.length) throw new Error(`The attachment ${attachment.fileName} is empty.`);

    if (attachment.mimeType === "application/pdf") {
      const text = await extractPdfStructure(buffer);
      if (text) extractedText.push(`PDF ${attachment.fileName}\n${text}`);
      else notes.push(`${attachment.fileName}: no selectable text was found; review scanned pages manually.`);
      continue;
    }

    if (attachment.mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
      const result = await extractDocxStructure(buffer);
      if (result.text) extractedText.push(`DOCX ${attachment.fileName}\n${result.text}`);
      if (result.missingAltCount > 0) {
        findings.push({
          ruleId: "VIS-ALT",
          severity: "MEDIUM",
          category: "Missing alternative text",
          quote: `${attachment.fileName} contains ${result.missingAltCount} image${result.missingAltCount === 1 ? "" : "s"} without alternative text.`,
          suggestion: "Add concise, meaningful alt text to each informative image in the document.",
          explanation: "The document structure contains image elements without an alt attribute.",
        });
      }
      continue;
    }

    if (attachment.mimeType.startsWith("image/")) {
      const audit = await auditImage(attachment, buffer, approvedAssets);
      extractedText.push(...audit.text);
      findings.push(...audit.findings);
      notes.push(...audit.notes);
    }
  }

  return {
    extractedText: extractedText.join("\n\n").slice(0, MAX_DOCUMENT_TEXT)
      ? [extractedText.join("\n\n").slice(0, MAX_DOCUMENT_TEXT)]
      : [],
    findings,
    notes,
  };
}

async function extractPdfStructure(buffer: Buffer): Promise<string> {
  const document = await pdfjs.getDocument({
    data: new Uint8Array(buffer),
    isEvalSupported: false,
    useSystemFonts: true,
  }).promise;
  const output: string[] = [];
  let totalCharacters = 0;

  try {
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      const items = content.items.flatMap((item) => {
        if (!("str" in item) || typeof item.str !== "string" || !item.str.trim()) return [];
        const transform = "transform" in item ? item.transform : undefined;
        if (!transform || transform.length < 6) return [];
        return [{
          text: item.str.trim(),
          x: Number(transform[4]),
          y: Number(transform[5]),
          fontSize: Math.round(Math.hypot(Number(transform[2]), Number(transform[3])) * 10) / 10,
        }];
      }).sort((a, b) => b.y - a.y || a.x - b.x);

      const lines: Array<{ y: number; items: typeof items }> = [];
      for (const item of items) {
        let line = lines.find((candidate) => Math.abs(candidate.y - item.y) <= 2.5);
        if (!line) {
          line = { y: item.y, items: [] };
          lines.push(line);
        }
        line.items.push(item);
      }
      lines.sort((a, b) => b.y - a.y);
      for (const line of lines) {
        line.items.sort((a, b) => a.x - b.x);
        const text = line.items.map((item) => item.text).join(" ");
        const x = Math.max(0, Math.round(line.items[0]?.x ?? 0));
        const fontSize = Math.max(...line.items.map((item) => item.fontSize));
        const block = `Page ${pageNumber} · x ${x} · approx. ${fontSize} pt: ${text}`;
        output.push(block);
        totalCharacters += block.length;
        if (totalCharacters >= MAX_DOCUMENT_TEXT) return output.join("\n").slice(0, MAX_DOCUMENT_TEXT);
      }
    }
  } finally {
    await document.destroy();
  }
  return output.join("\n").slice(0, MAX_DOCUMENT_TEXT);
}

async function extractDocxStructure(buffer: Buffer): Promise<{ text: string; missingAltCount: number }> {
  const [plain, structured] = await Promise.all([
    mammoth.extractRawText({ buffer }),
    mammoth.convertToHtml({ buffer }),
  ]);
  const blockPattern = /<(h[1-6]|p|li|tr|blockquote)\b[^>]*>([\s\S]*?)<\/\1>/gi;
  const blocks: string[] = [];
  for (const match of structured.value.matchAll(blockPattern)) {
    const tag = match[1]!.toUpperCase();
    const text = match[2]!.replace(/<br\s*\/?>/gi, " · ").replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ").trim();
    if (text) blocks.push(`${tag}: ${text}`);
  }
  const missingAltCount = [...structured.value.matchAll(/<img\b(?![^>]*\balt\s*=)[^>]*>/gi)].length;
  const text = blocks.length ? blocks.join("\n") : plain.value.trim();
  return { text: text.slice(0, MAX_DOCUMENT_TEXT), missingAltCount };
}

async function auditImage(
  attachment: UploadedAttachment,
  image: Buffer,
  approvedAssets: ApprovedAssetReference[],
): Promise<{ text: string[]; findings: AutomaticFinding[]; notes: string[] }> {
  const output: string[] = [];
  const findings: AutomaticFinding[] = [];
  const notes: string[] = [];
  const isLogo =
    attachment.assetType === "logo" ||
    attachment.assetType === "wordmark" ||
    attachment.assetType === "icon" ||
    /\b(logo|wordmark|brand.?mark|brand.?icon)\b/i.test(attachment.fileName);

  if (!attachment.altText?.trim()) {
    findings.push({
      ruleId: "VIS-ALT",
      severity: "MEDIUM",
      category: "Missing alternative text",
      quote: `${attachment.fileName} was uploaded without proposed alt text.`,
      suggestion: "Add concise alt text describing the image's purpose and meaningful visual information.",
      explanation: "No alternative text was provided with this visual asset.",
    });
  }

  if (isLogo) {
    const matchingAssets = approvedAssets.filter((asset) =>
      asset.assetType === (attachment.assetType ?? "logo"),
    );
    if (!matchingAssets.length) {
      findings.push({
        ruleId: "VIS-LOGO",
        severity: "MEDIUM",
        category: "No approved logo reference",
        quote: attachment.fileName,
        suggestion: "Register the approved logo, wordmark, or icon in Canon before using this asset.",
        explanation: "The workspace has no registered approved asset of this type, so an automated comparison cannot confirm this file.",
      });
    } else {
      const uploadedHash = await perceptualHash(image);
      const closest = matchingAssets
        .map((asset) => ({ asset, distance: hammingDistance(uploadedHash, asset.perceptualHash) }))
        .sort((a, b) => a.distance - b.distance)[0]!;
      if (closest.distance > 8) {
        findings.push({
          ruleId: "VIS-LOGO",
          severity: "HIGH",
          category: "Logo differs from approved reference",
          quote: attachment.fileName,
          suggestion: `Replace this file with the registered ${closest.asset.label} master asset.`,
          explanation: `Its perceptual hash differs from the closest approved ${closest.asset.assetType} by ${closest.distance}/64 bits. This is a similarity warning, not a definitive identity judgment; confirm it visually.`,
        });
      }
    }
  }

  const worker = await getOcrWorker();
  const { data: normalized, info } = await sharp(image, { limitInputPixels: MAX_IMAGE_PIXELS })
    .rotate()
    .resize({ width: 2048, height: 2048, fit: "inside", withoutEnlargement: true })
    .png()
    .toBuffer({ resolveWithObject: true });
  const recognized = await worker.recognize(normalized);
  const words = recognized.data.words.filter((word) => word.text.trim() && word.confidence >= 60);
  const text = words.map((word) => word.text.trim()).join(" ").slice(0, 3000);
  if (text) output.push(`OCR text from ${attachment.fileName}: ${text}`);

  const raw = await sharp(normalized, { limitInputPixels: MAX_IMAGE_PIXELS })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  const ratios = words.flatMap((word) => {
    const result = measureWordContrast(
      raw.data,
      raw.info.width,
      raw.info.height,
      raw.info.channels,
      word.bbox,
    );
    if (!result || result.backgroundVariation > 0.035) return [];
    const largeText = word.bbox.y1 - word.bbox.y0 >= 24;
    const threshold = largeText ? 3 : 4.5;
    return [{ word: word.text.trim(), ratio: result.ratio, threshold, largeText }];
  }).filter((measurement) => measurement.ratio < measurement.threshold);

  if (ratios.length) {
    const worst = ratios.sort((a, b) => a.ratio - b.ratio)[0]!;
    findings.push({
      ruleId: "VIS-CONTRAST",
      severity: "MEDIUM",
      category: "Text contrast below WCAG AA",
      quote: worst.word,
      suggestion: "Increase the text/background contrast or add a solid, high-contrast backing behind the text.",
      explanation: `The local pixel estimate is ${worst.ratio.toFixed(2)}:1, below the ${worst.threshold}:1 WCAG AA threshold for ${worst.largeText ? "large" : "normal"} text. Complex backgrounds are not scored automatically.`,
    });
  }

  if (!text) notes.push(`${attachment.fileName}: OCR found no readable text; check manually.`);
  if (!info.width || !info.height) notes.push(`${attachment.fileName}: image dimensions could not be read.`);
  return { text: output, findings, notes };
}

async function getOcrWorker(): Promise<Worker> {
  if (!ocrWorkerPromise) {
    ocrWorkerPromise = createWorker("eng", 1, {
      langPath: englishDataPath,
      gzip: true,
      cacheMethod: "none",
    }).catch((error: unknown) => {
      ocrWorkerPromise = undefined;
      throw error;
    });
  }
  return ocrWorkerPromise;
}

type WordBox = { x0: number; y0: number; x1: number; y1: number };

function measureWordContrast(
  pixels: Buffer,
  width: number,
  height: number,
  channels: number,
  box: WordBox,
): { ratio: number; backgroundVariation: number } | null {
  if (channels < 3 || box.x1 <= box.x0 || box.y1 <= box.y0) return null;
  const x0 = Math.max(0, Math.floor(box.x0));
  const y0 = Math.max(0, Math.floor(box.y0));
  const x1 = Math.min(width - 1, Math.ceil(box.x1));
  const y1 = Math.min(height - 1, Math.ceil(box.y1));
  const border: number[] = [];
  const foreground: number[] = [];
  const stepX = Math.max(1, Math.floor((x1 - x0) / 40));
  const stepY = Math.max(1, Math.floor((y1 - y0) / 20));
  const margin = Math.max(2, Math.floor(Math.min(x1 - x0, y1 - y0) * 0.12));

  for (let y = Math.max(0, y0 - margin); y <= Math.min(height - 1, y1 + margin); y += stepY) {
    for (let x = Math.max(0, x0 - margin); x <= Math.min(width - 1, x1 + margin); x += stepX) {
      const luminance = pixelLuminance(pixels, (y * width + x) * channels);
      const inside = x >= x0 && x <= x1 && y >= y0 && y <= y1;
      (inside ? foreground : border).push(luminance);
    }
  }
  if (border.length < 4 || foreground.length < 4) return null;
  const background = median(border);
  const backgroundVariation = median(border.map((value) => Math.abs(value - background)));
  const foregroundPixels = foreground.filter((value) => Math.abs(value - background) > 0.08);
  if (!foregroundPixels.length) return null;
  const foregroundLuminance = median(foregroundPixels);
  return {
    ratio: contrastRatio(foregroundLuminance, background),
    backgroundVariation,
  };
}

function pixelLuminance(pixels: Buffer, offset: number): number {
  const linear = (value: number) => {
    const channel = value / 255;
    return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * linear(pixels[offset]!) +
    0.7152 * linear(pixels[offset + 1]!) +
    0.0722 * linear(pixels[offset + 2]!);
}

export function contrastRatio(foreground: number, background: number): number {
  const lighter = Math.max(foreground, background);
  const darker = Math.min(foreground, background);
  return (lighter + 0.05) / (darker + 0.05);
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)] ?? 0;
}

export function currentModuleDirectory(): string {
  return path.dirname(fileURLToPath(import.meta.url));
}
