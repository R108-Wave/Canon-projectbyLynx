import sharp from "sharp";

export async function perceptualHash(image: Buffer): Promise<string> {
  const { data, info } = await sharp(image, { limitInputPixels: 25_000_000 })
    .rotate()
    .greyscale()
    .resize(32, 32, { fit: "fill" })
    .raw()
    .toBuffer({ resolveWithObject: true });

  if (info.width !== 32 || info.height !== 32 || info.channels !== 1) {
    throw new Error("The image could not be normalized for comparison.");
  }

  const coefficients: number[] = [];
  for (let v = 0; v < 8; v += 1) {
    for (let u = 0; u < 8; u += 1) {
      let sum = 0;
      for (let y = 0; y < 32; y += 1) {
        const vertical = Math.cos(((2 * y + 1) * v * Math.PI) / 64);
        for (let x = 0; x < 32; x += 1) {
          const horizontal = Math.cos(((2 * x + 1) * u * Math.PI) / 64);
          sum += data[y * 32 + x]! * horizontal * vertical;
        }
      }
      coefficients.push(sum);
    }
  }

  const lowFrequency = coefficients.slice(1).sort((a, b) => a - b);
  const median = lowFrequency[Math.floor(lowFrequency.length / 2)]!;
  let hash = 0n;
  for (let index = 1; index < coefficients.length; index += 1) {
    if (coefficients[index]! > median) {
      hash |= 1n << BigInt(63 - index);
    }
  }
  return hash.toString(16).padStart(16, "0");
}

export function hammingDistance(left: string, right: string): number {
  if (!/^[0-9a-f]{16}$/i.test(left) || !/^[0-9a-f]{16}$/i.test(right)) {
    throw new Error("Perceptual hashes must be 64-bit hexadecimal values.");
  }
  let difference = BigInt(`0x${left}`) ^ BigInt(`0x${right}`);
  let bits = 0;
  while (difference) {
    bits += Number(difference & 1n);
    difference >>= 1n;
  }
  return bits;
}
