import { getAuth } from "@clerk/express";
import {
  AddCanonApprovedAssetBody,
  AddCanonApprovedAssetResponse,
} from "@workspace/api-zod";
import {
  canonApprovedAssetsTable,
  canonAuditEventsTable,
  canonWorkspacesTable,
  db,
} from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { ensureCanonMember } from "../lib/canonWorkspace";
import { perceptualHash } from "../lib/perceptualHash";

const router: IRouter = Router();
const MAX_IMAGE_BYTES = 2 * 1024 * 1024;

router.post("/canon/approved-assets", async (req, res): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign in to manage approved brand assets." });
    return;
  }
  const parsed = AddCanonApprovedAssetBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "The approved asset details are invalid." });
    return;
  }
  const context = await ensureCanonMember(userId);
  if (context.member.role !== "Brand Admin") {
    res.status(403).json({ error: "Only a Brand Admin can manage approved assets." });
    return;
  }

  const bytes = Buffer.from(parsed.data.data, "base64");
  if (!bytes.length || bytes.length > MAX_IMAGE_BYTES) {
    res.status(400).json({ error: "Choose an image no larger than 2 MB." });
    return;
  }

  try {
    const hash = await perceptualHash(bytes);
    const [asset] = await db.transaction(async (tx) => {
      const [created] = await tx.insert(canonApprovedAssetsTable).values({
        workspaceId: context.workspace.id,
        label: parsed.data.label.trim(),
        fileName: parsed.data.fileName.trim(),
        assetType: parsed.data.assetType,
        perceptualHash: hash,
        createdBy: userId,
      }).returning();
      if (!created) throw new Error("The approved asset could not be saved.");
      await tx.update(canonWorkspacesTable)
        .set({ revision: context.workspace.revision + 1, updatedAt: new Date() })
        .where(eq(canonWorkspacesTable.id, context.workspace.id));
      await tx.insert(canonAuditEventsTable).values({
        workspaceId: context.workspace.id,
        actorUserId: userId,
        actorRole: context.member.role,
        action: "Approved visual asset added",
        detail: { assetId: created.id, label: created.label, assetType: created.assetType },
      });
      return [created] as const;
    });
    res.status(201).json(AddCanonApprovedAssetResponse.parse({
      id: asset.id,
      label: asset.label,
      fileName: asset.fileName,
      assetType: asset.assetType,
      perceptualHash: asset.perceptualHash,
      createdAt: asset.createdAt,
    }));
  } catch (error) {
    req.log.warn({ error }, "Could not register approved visual asset");
    res.status(400).json({ error: "The image could not be processed. Use a valid PNG, JPEG, WebP, or GIF file." });
  }
});

router.delete("/canon/approved-assets/:assetId", async (req, res): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign in to manage approved brand assets." });
    return;
  }
  const context = await ensureCanonMember(userId);
  if (context.member.role !== "Brand Admin") {
    res.status(403).json({ error: "Only a Brand Admin can manage approved assets." });
    return;
  }
  if (!/^[0-9a-f-]{36}$/i.test(req.params.assetId)) {
    res.status(400).json({ error: "The approved asset ID is invalid." });
    return;
  }
  try {
    const removed = await db.transaction(async (tx) => {
      const rows = await tx.delete(canonApprovedAssetsTable)
        .where(and(
          eq(canonApprovedAssetsTable.id, req.params.assetId),
          eq(canonApprovedAssetsTable.workspaceId, context.workspace.id),
        ))
        .returning();
      if (!rows.length) return false;
      await tx.update(canonWorkspacesTable)
        .set({ revision: context.workspace.revision + 1, updatedAt: new Date() })
        .where(eq(canonWorkspacesTable.id, context.workspace.id));
      await tx.insert(canonAuditEventsTable).values({
        workspaceId: context.workspace.id,
        actorUserId: userId,
        actorRole: context.member.role,
        action: "Approved visual asset removed",
        detail: { assetId: req.params.assetId },
      });
      return true;
    });
    if (!removed) {
      res.status(404).json({ error: "That approved asset was not found in your workspace." });
      return;
    }
    res.json({ success: true });
  } catch (error) {
    req.log.error({ error }, "Could not remove approved visual asset");
    res.status(500).json({ error: "The approved asset could not be removed. Try again." });
  }
});

export default router;
