import { Router, type IRouter } from "express";
import healthRouter from "./health";
import canonRouter from "./canon";
import workspaceRouter from "./workspace";
import approvedAssetsRouter from "./approvedAssets";

const router: IRouter = Router();

router.use(healthRouter);
router.use(canonRouter);
router.use(workspaceRouter);
router.use(approvedAssetsRouter);

export default router;
