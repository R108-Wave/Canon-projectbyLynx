import { getAuth } from "@clerk/express";
import {
  GetCanonWorkspaceResponse,
  UpdateCanonWorkspaceBody,
} from "@workspace/api-zod";
import {
  canonAuditEventsTable,
  canonFindingsTable,
  canonMembersTable,
  canonReviewsTable,
  canonRulesTable,
  canonRuleVersionsTable,
  canonWorkspacesTable,
  db,
  type CanonWorkspaceSettings,
} from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { ensureCanonMember, readCanonWorkspace } from "../lib/canonWorkspace";

const router: IRouter = Router();

class UpdateError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

router.get("/canon/workspace", async (req, res): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign in to open your CANON workspace." });
    return;
  }
  try {
    const workspace = await readCanonWorkspace(userId);
    res.json(GetCanonWorkspaceResponse.parse(workspace));
  } catch (error) {
    req.log.error({ error }, "Could not load CANON workspace");
    res.status(500).json({ error: "Your workspace could not be loaded. Try again." });
  }
});

router.patch("/canon/workspace", async (req, res): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign in to update your CANON workspace." });
    return;
  }
  const parsed = UpdateCanonWorkspaceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "The workspace update is invalid." });
    return;
  }

  try {
    const { workspace: contextWorkspace, member } = await ensureCanonMember(userId);
    await db.transaction(async (tx) => {
      const [workspace] = await tx
        .select()
        .from(canonWorkspacesTable)
        .where(eq(canonWorkspacesTable.id, contextWorkspace.id))
        .for("update")
        .limit(1);
      if (!workspace) throw new UpdateError("Workspace was not found.", 404);
      if (workspace.revision !== parsed.data.expectedRevision) {
        throw new UpdateError(
          "This workspace changed in another tab or session. It has been refreshed; retry your change.",
          409,
        );
      }

      const role = member.role;
      const canManage = role === "Brand Admin";
      const canReview = role === "Brand Admin" || role === "Reviewer";
      const [currentRules, currentReviews, currentFindings] = await Promise.all([
        tx.select().from(canonRulesTable).where(eq(canonRulesTable.workspaceId, workspace.id)),
        tx.select().from(canonReviewsTable).where(eq(canonReviewsTable.workspaceId, workspace.id)),
        tx.select().from(canonFindingsTable).where(eq(canonFindingsTable.workspaceId, workspace.id)),
      ]);
      const requestedRulesById = new Map(parsed.data.rules.map((rule) => [rule.id, rule]));
      const requestedReviewsById = new Map(parsed.data.reviews.map((review) => [review.id, review]));
      if (requestedRulesById.size !== parsed.data.rules.length || requestedReviewsById.size !== parsed.data.reviews.length) {
        throw new UpdateError("The update contains duplicate rule or review IDs.", 400);
      }
      if (!canManage && (parsed.data.name !== workspace.name || parsed.data.rules.length > 0)) {
        const ruleChange = parsed.data.rules.some((input) => {
          const current = currentRules.find((rule) => rule.ruleId === input.id);
          return !current || current.text !== input.text || current.type !== input.type ||
            current.owner !== input.owner || current.status !== input.status ||
            current.expiry !== dateValue(input.expiry) ||
            JSON.stringify(current.applies) !== JSON.stringify(input.applies);
        }) || currentRules.some((rule) => !requestedRulesById.has(rule.ruleId));
        if (parsed.data.name !== workspace.name || ruleChange) {
          throw new UpdateError("Only a Brand Admin can change Canon rules or the workspace name.", 403);
        }
      }

      if (requestedReviewsById.size !== currentReviews.length ||
          currentReviews.some((review) => !requestedReviewsById.has(review.id))) {
        throw new UpdateError("Reviews cannot be added or removed through this update.", 400);
      }

      const findingsByReview = new Map<string, typeof currentFindings>();
      for (const finding of currentFindings) {
        const list = findingsByReview.get(finding.reviewId) ?? [];
        list.push(finding);
        findingsByReview.set(finding.reviewId, list);
      }

      const now = new Date();
      let rulesChanged = false;
      let reviewsChanged = false;
      let settingsChanged = JSON.stringify(member.settings) !== JSON.stringify(parsed.data.settings);
      const audit: Array<{ action: string; detail: Record<string, unknown> }> = [];

      if (canManage && parsed.data.name !== workspace.name) {
        audit.push({ action: "Workspace renamed", detail: { name: parsed.data.name } });
      }

      if (canManage) {
        for (const input of parsed.data.rules) {
          const current = currentRules.find((rule) => rule.ruleId === input.id);
          const expiry = dateValue(input.expiry);
          if (!current) {
            const [created] = await tx.insert(canonRulesTable).values({
              workspaceId: workspace.id,
              ruleId: input.id,
              type: input.type,
              text: input.text,
              owner: input.owner,
              status: input.status,
              expiry,
              applies: input.applies,
              version: 1,
              createdBy: userId,
            }).returning();
            if (created) {
              await tx.insert(canonRuleVersionsTable).values({
                workspaceId: workspace.id,
                ruleId: created.ruleId,
                version: 1,
                type: created.type,
                text: created.text,
                owner: created.owner,
                status: created.status,
                expiry: created.expiry,
                applies: created.applies,
                actorUserId: userId,
              });
              rulesChanged = true;
              audit.push({ action: "Rule created", detail: { ruleId: created.ruleId } });
            }
            continue;
          }

          const changed = current.type !== input.type || current.text !== input.text ||
            current.owner !== input.owner || current.status !== input.status ||
            current.expiry !== expiry ||
            JSON.stringify(current.applies) !== JSON.stringify(input.applies);
          if (!changed) continue;

          const version = current.version + 1;
          await tx.update(canonRulesTable).set({
            type: input.type,
            text: input.text,
            owner: input.owner,
            status: input.status,
            expiry,
            applies: input.applies,
            version,
            updatedAt: now,
          }).where(and(
            eq(canonRulesTable.workspaceId, workspace.id),
            eq(canonRulesTable.ruleId, input.id),
          ));
          await tx.insert(canonRuleVersionsTable).values({
            workspaceId: workspace.id,
            ruleId: input.id,
            version,
            type: input.type,
            text: input.text,
            owner: input.owner,
            status: input.status,
            expiry,
            applies: input.applies,
            actorUserId: userId,
          });
          rulesChanged = true;
          audit.push({
            action: input.text !== current.text ? "Rule rewritten" : "Rule updated",
            detail: { ruleId: input.id, version },
          });
        }

        for (const current of currentRules) {
          if (requestedRulesById.has(current.ruleId) || current.status === "archived") continue;
          const version = current.version + 1;
          await tx.update(canonRulesTable).set({
            status: "archived",
            version,
            updatedAt: now,
          }).where(eq(canonRulesTable.id, current.id));
          await tx.insert(canonRuleVersionsTable).values({
            workspaceId: workspace.id,
            ruleId: current.ruleId,
            version,
            type: current.type,
            text: current.text,
            owner: current.owner,
            status: "archived",
            expiry: current.expiry,
            applies: current.applies,
            actorUserId: userId,
          });
          rulesChanged = true;
          audit.push({ action: "Rule archived", detail: { ruleId: current.ruleId, version } });
        }
      }

      for (const review of currentReviews) {
        const update = requestedReviewsById.get(review.id)!;
        const creator = review.creatorUserId === userId;
        const findingUpdates = new Map(update.findings.map((finding) => [finding.id, finding]));
        const reviewFindings = findingsByReview.get(review.id) ?? [];
        if (findingUpdates.size !== update.findings.length ||
            findingUpdates.size !== reviewFindings.length ||
            reviewFindings.some((finding) => !findingUpdates.has(finding.id))) {
          throw new UpdateError("A review's findings cannot be added or removed.", 400);
        }

        if (update.status !== review.status) {
          const creatorSubmit =
            (review.status === "draft" || review.status === "rejected") &&
            update.status === "queued" &&
            (creator || canManage);
          const reviewerDecision =
            review.status === "queued" &&
            (update.status === "approved" || update.status === "rejected") &&
            canReview;
          if (!creatorSubmit && !reviewerDecision) {
            throw new UpdateError("Your role cannot make this review status change.", 403);
          }
          await tx.update(canonReviewsTable)
            .set({ status: update.status, updatedAt: now })
            .where(eq(canonReviewsTable.id, review.id));
          reviewsChanged = true;
          audit.push({
            action: update.status === "queued" ? "Submitted for review" :
              update.status === "approved" ? "Review approved" : "Review returned",
            detail: { reviewId: review.id, title: review.title },
          });
        }

        for (const current of reviewFindings) {
          const findingUpdate = findingUpdates.get(current.id)!;
          if (findingUpdate.status !== current.creatorStatus) {
            if (!(creator || canManage) || (review.status !== "draft" && review.status !== "rejected")) {
              throw new UpdateError("Only the draft's creator can accept or dispute findings before review.", 403);
            }
            await tx.update(canonFindingsTable)
              .set({ creatorStatus: findingUpdate.status })
              .where(eq(canonFindingsTable.id, current.id));
            reviewsChanged = true;
            audit.push({
              action: findingUpdate.status === "disputed" ? "Finding disputed" :
                findingUpdate.status === "accepted" ? "Finding accepted" : "Finding reopened",
              detail: { findingId: current.id, ruleId: current.ruleId },
            });
          }
          if (findingUpdate.reviewerStatus !== current.reviewerStatus) {
            if (!canReview || review.status !== "queued" || findingUpdate.reviewerStatus === null) {
              throw new UpdateError("A reviewer can resolve findings only while the review is queued.", 403);
            }
            await tx.update(canonFindingsTable)
              .set({ reviewerStatus: findingUpdate.reviewerStatus })
              .where(eq(canonFindingsTable.id, current.id));
            reviewsChanged = true;
            audit.push({
              action: findingUpdate.reviewerStatus !== current.creatorStatus ? "Finding overridden" : "Finding confirmed",
              detail: { findingId: current.id, ruleId: current.ruleId },
            });
          }
        }
      }

      if (settingsChanged) {
        await tx.update(canonMembersTable)
          .set({ settings: parsed.data.settings })
          .where(eq(canonMembersTable.id, member.id));
        audit.push({ action: "Preferences updated", detail: {} });
      }
      if (parsed.data.name !== workspace.name && canManage) {
        await tx.update(canonWorkspacesTable)
          .set({ name: parsed.data.name })
          .where(eq(canonWorkspacesTable.id, workspace.id));
      }
      if (rulesChanged) {
        await tx.update(canonWorkspacesTable)
          .set({ canonicalVersion: workspace.canonicalVersion + 1 })
          .where(eq(canonWorkspacesTable.id, workspace.id));
      }
      if (rulesChanged || reviewsChanged || settingsChanged || parsed.data.name !== workspace.name) {
        await tx.update(canonWorkspacesTable)
          .set({ revision: workspace.revision + 1, updatedAt: now })
          .where(eq(canonWorkspacesTable.id, workspace.id));
      }
      if (audit.length) {
        await tx.insert(canonAuditEventsTable).values(
          audit.map((event) => ({
            workspaceId: workspace.id,
            actorUserId: userId,
            actorRole: role,
            action: event.action,
            detail: event.detail,
          })),
        );
      }
    });

    const response = await readCanonWorkspace(userId);
    res.json(GetCanonWorkspaceResponse.parse(response));
  } catch (error) {
    if (error instanceof UpdateError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    req.log.error({ error }, "Could not update CANON workspace");
    res.status(500).json({ error: "Your changes could not be saved. Try again." });
  }
});

function dateValue(value: Date | null): string | null {
  return value ? value.toISOString().slice(0, 10) : null;
}

export default router;
