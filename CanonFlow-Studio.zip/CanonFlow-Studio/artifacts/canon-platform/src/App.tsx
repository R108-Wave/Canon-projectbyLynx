import { useEffect, useMemo, useRef, useState, type ReactNode, type RefObject } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Route, Switch, Link, useLocation, Router as WouterRouter } from 'wouter';
import { useAnalyzeCanonDraft } from '@workspace/api-client-react';
import type { CanonAttachment, CanonFinding, CanonRule as ApiCanonRule } from '@workspace/api-client-react';
import {
  Activity, AlertCircle, ArrowRight, BookOpen, Check, CheckCircle2, CircleHelp,
  ClipboardCheck, CloudOff, Copy, Download, FileText, Gauge, History, Inbox, Info,
  LockKeyhole, MoreHorizontal, Paperclip, Plus, Search, Settings, Shield, ShieldCheck,
  Trash2, Upload, X, XCircle,
} from 'lucide-react';
import NotFound from '@/pages/not-found';

type Role = 'Creator' | 'Reviewer' | 'Brand Admin';
type RuleStatus = 'active' | 'draft' | 'archived';
type FindingStatus = 'open' | 'accepted' | 'disputed';
type ReviewStatus = 'draft' | 'queued' | 'approved' | 'rejected';
type Rule = ApiCanonRule & { owner: string; status: RuleStatus; expiry?: string; applies: string[]; disputes: number };
type Finding = CanonFinding & { status: FindingStatus };
type ReviewItem = {
  id: string; draft: string; createdAt: string; updatedAt: string; findings: Finding[];
  status: ReviewStatus; summary: string; attachmentNames: string[]; title: string;
};
type AuditEvent = { id: string; at: string; action: string; detail: string; actor: Role };
type SettingsData = { compact: boolean; showTips: boolean; colorMode: 'light' | 'dark' };
type Workspace = { rules: Rule[]; reviews: ReviewItem[]; audit: AuditEvent[]; role: Role; settings: SettingsData };

const STORE_KEY = 'canon-brand-governance-workspace-v1';
const MAX_ATTACHMENTS = 5;
const MAX_TOTAL_BYTES = 4 * 1024 * 1024;
const ALLOWED_TYPES = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp', 'image/gif'];
const queryClient = new QueryClient();
const starterRules: Rule[] = [
  { id: 'VOICE-01', type: 'Voice', text: 'Speak with quiet confidence. Prefer clear, direct language over hype or superlatives.', owner: 'Brand team', status: 'active', applies: ['Campaigns', 'Social'], disputes: 0 },
  { id: 'CLAIM-02', type: 'Claims', text: 'Product performance claims must be supported by a current, published source.', owner: 'Legal', status: 'active', applies: ['All content'], disputes: 0 },
  { id: 'VIS-03', type: 'Visual identity', text: 'Do not stretch, recolor, or place the wordmark over visually busy backgrounds.', owner: 'Design', status: 'active', applies: ['Visual'], disputes: 0 },
  { id: 'INCL-04', type: 'Inclusion', text: 'Use people-first language and avoid assumptions about a reader’s identity or ability.', owner: 'Brand team', status: 'active', applies: ['All content'], disputes: 0 },
  { id: 'SOC-05', type: 'Social', text: 'Keep social captions useful and specific. Avoid engagement bait and manufactured urgency.', owner: 'Editorial', status: 'active', applies: ['Social'], disputes: 0 },
];
const initialSettings: SettingsData = { compact: false, showTips: true, colorMode: 'light' };
const roles: Role[] = ['Creator', 'Reviewer', 'Brand Admin'];
const routes = [
  { href: '/', title: 'Overview', icon: Gauge },
  { href: '/review', title: 'Review a draft', icon: ClipboardCheck },
  { href: '/guidelines', title: 'Canon rules', icon: BookOpen },
  { href: '/queue', title: 'Review queue', icon: Inbox },
  { href: '/insights', title: 'Insights', icon: Activity },
  { href: '/settings', title: 'Settings', icon: Settings },
];

function loadWorkspace(): Workspace {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const saved = JSON.parse(raw) as Partial<Workspace>;
      return {
        rules: Array.isArray(saved.rules) ? saved.rules : starterRules,
        reviews: Array.isArray(saved.reviews) ? saved.reviews : [],
        audit: Array.isArray(saved.audit) ? saved.audit : [],
        role: roles.includes(saved.role as Role) ? saved.role as Role : 'Creator',
        settings: { ...initialSettings, ...saved.settings },
      };
    }
  } catch { /* Corrupt local data is recoverable from settings. */ }
  return { rules: starterRules, reviews: [], audit: [], role: 'Creator', settings: initialSettings };
}

function App() {
  const [workspace, setWorkspace] = useState<Workspace>(loadWorkspace);
  const [path] = useLocation();
  const [toast, setToast] = useState('');
  const [dialog, setDialog] = useState<'rule' | 'import' | 'reset' | null>(null);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [ruleSearch, setRuleSearch] = useState('');
  const [ruleFilter, setRuleFilter] = useState('all');
  const [queueSearch, setQueueSearch] = useState('');
  const [queueFilter, setQueueFilter] = useState('pending');
  const [draftText, setDraftText] = useState('');
  const [draftTitle, setDraftTitle] = useState('');
  const [attachments, setAttachments] = useState<CanonAttachment[]>([]);
  const [attachmentNames, setAttachmentNames] = useState<string[]>([]);
  const [activeReviewId, setActiveReviewId] = useState<string | null>(null);
  const [settingsTab, setSettingsTab] = useState('Preferences');
  const [importText, setImportText] = useState('');
  const [installReady, setInstallReady] = useState(false);
  const installPrompt = useRef<(Event & { prompt?: () => Promise<void> }) | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const importInput = useRef<HTMLInputElement>(null);
  const mutation = useAnalyzeCanonDraft();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(workspace)); } catch { setToast('Browser storage is full. Export your workspace before continuing.'); }
    document.documentElement.classList.toggle('dark', workspace.settings.colorMode === 'dark');
  }, [workspace]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 3000);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    if ('serviceWorker' in navigator && import.meta.env.PROD) navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch(() => undefined);
  }, []);
  useEffect(() => {
    const handleInstall = (event: Event) => {
      event.preventDefault();
      installPrompt.current = event as Event & { prompt?: () => Promise<void> };
      setInstallReady(true);
    };
    window.addEventListener('beforeinstallprompt', handleInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleInstall);
  }, []);
  const requestInstall = async () => {
    if (installPrompt.current?.prompt) {
      await installPrompt.current.prompt();
      installPrompt.current = null;
      setInstallReady(false);
    } else notify('Use your browser menu and choose “Install app” or “Add to Home Screen.”');
  };

  const save = (patch: Partial<Workspace>, action?: string, detail?: string) => {
    setWorkspace(old => ({
      ...old, ...patch,
      audit: action ? [{ id: crypto.randomUUID(), at: new Date().toISOString(), action, detail: detail || '', actor: old.role }, ...old.audit].slice(0, 250) : patch.audit ?? old.audit,
    }));
  };
  const notify = (message: string) => setToast(message);
  const activeRules = useMemo(() => workspace.rules.filter(r => r.status === 'active'), [workspace.rules]);
  const pendingQueue = useMemo(() => workspace.reviews.filter(item => item.status === 'queued'), [workspace.reviews]);
  const selectedReview = workspace.reviews.find(item => item.id === activeReviewId) || workspace.reviews[0] || null;
  const updateReview = (id: string, updater: (item: ReviewItem) => ReviewItem, action?: string, detail?: string) =>
    setWorkspace(old => ({
      ...old,
      reviews: old.reviews.map(item => item.id === id ? updater(item) : item),
      audit: action ? [{ id: crypto.randomUUID(), at: new Date().toISOString(), action, detail: detail || '', actor: old.role }, ...old.audit].slice(0, 250) : old.audit,
    }));
  const setRole = (role: Role) => save({ role }, 'Role changed', `Demo role changed to ${role}`);
  const canManage = workspace.role === 'Brand Admin';
  const canReview = workspace.role !== 'Creator';

  const handleAnalyze = () => {
    const cleanDraft = draftText.trim();
    if (!cleanDraft && !attachments.length) { notify('Add draft text or an attachment before requesting a review.'); return; }
    if (!activeRules.length) { notify('There are no active Canon rules to review against.'); return; }
    mutation.mutate({ data: { draftText: cleanDraft, rules: activeRules.map(({ id, type, text }) => ({ id, type, text })), attachments } }, {
      onSuccess: result => {
        const now = new Date().toISOString();
        const item: ReviewItem = {
          id: crypto.randomUUID(), draft: cleanDraft, title: draftTitle.trim() || cleanDraft.slice(0, 48).replace(/\s+/g, ' ') + (cleanDraft.length > 48 ? '…' : '') || attachmentNames[0] || 'Untitled review',
          createdAt: now, updatedAt: now, findings: result.findings.map(f => ({ ...f, status: 'open' })), status: 'draft',
          summary: result.summary, attachmentNames: [...attachmentNames],
        };
        setWorkspace(old => ({
          ...old, reviews: [item, ...old.reviews],
          audit: [{ id: crypto.randomUUID(), at: now, action: 'Draft analyzed', detail: item.title, actor: old.role }, ...old.audit].slice(0, 250),
        }));
        setActiveReviewId(item.id);
        notify('Review complete. Findings are ready to inspect.');
      },
    });
  };
  const encodeFile = (file: File) => new Promise<CanonAttachment>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.onload = () => {
      const result = String(reader.result || '');
      resolve({ fileName: file.name, mimeType: file.type as CanonAttachment['mimeType'], data: result.split(',')[1] || '' });
    };
    reader.readAsDataURL(file);
  });
  const addFiles = async (files: FileList | null) => {
    if (!files) return;
    const incoming = Array.from(files);
    if (attachments.length + incoming.length > MAX_ATTACHMENTS) { notify('Choose up to five attachments.'); return; }
    if (incoming.some(file => !ALLOWED_TYPES.includes(file.type))) { notify('Use PDF, PNG, JPEG, WebP, or GIF files.'); return; }
    if (incoming.some(file => file.size === 0)) { notify('Choose files that contain data.'); return; }
    if (incoming.some(file => file.size > MAX_TOTAL_BYTES)) { notify('Each attachment must be no larger than 4 MB.'); return; }
    const savedBytes = attachments.reduce((sum, attachment) => sum + Math.floor(attachment.data.length * 0.75), 0);
    const incomingBytes = incoming.reduce((sum, file) => sum + file.size, 0);
    if (savedBytes + incomingBytes > MAX_TOTAL_BYTES) { notify('The combined attachment limit is 4 MB.'); return; }
    try {
      const encoded = await Promise.all(incoming.map(encodeFile));
      setAttachments(old => [...old, ...encoded]);
      setAttachmentNames(old => [...old, ...incoming.map(file => file.name)]);
    } catch (error) { notify(error instanceof Error ? error.message : 'Attachment could not be read.'); }
  };
  const acceptFinding = (reviewId: string, findingId: string, status: FindingStatus) => {
    const action = status === 'accepted' ? 'Finding accepted' : status === 'disputed' ? 'Finding disputed' : 'Finding reopened';
    setWorkspace(old => {
      const existing = old.reviews.find(item => item.id === reviewId)?.findings.find(f => f.id === findingId);
      if (!existing) return old;
      const disputeDelta = Number(status === 'disputed') - Number(existing.status === 'disputed');
      return {
        ...old,
        reviews: old.reviews.map(item => item.id === reviewId ? {
          ...item, updatedAt: new Date().toISOString(),
          findings: item.findings.map(f => f.id === findingId ? { ...f, status } : f),
        } : item),
        rules: old.rules.map(rule => rule.id === existing.ruleId ? { ...rule, disputes: Math.max(0, rule.disputes + disputeDelta) } : rule),
        audit: [{ id: crypto.randomUUID(), at: new Date().toISOString(), action, detail: findingId, actor: old.role }, ...old.audit].slice(0, 250),
      };
    });
  };
  const submitToQueue = (id: string) => {
    updateReview(id, item => ({ ...item, status: 'queued', updatedAt: new Date().toISOString() }), 'Submitted for review', id);
    notify('Draft sent to the reviewer queue.');
  };
  const decideReview = (id: string, status: 'approved' | 'rejected') => {
    updateReview(id, item => ({ ...item, status, updatedAt: new Date().toISOString() }), status === 'approved' ? 'Draft approved' : 'Draft rejected', id);
    notify(status === 'approved' ? 'Draft approved.' : 'Draft returned to creator.');
  };
  const saveRule = (form: FormData) => {
    const next: Rule = {
      id: String(form.get('id')).trim().toUpperCase(), type: String(form.get('type')).trim(), text: String(form.get('text')).trim(),
      owner: String(form.get('owner')).trim() || 'Brand team', status: String(form.get('status')) as RuleStatus,
      expiry: String(form.get('expiry') || ''), applies: String(form.get('applies')).split(',').map(s => s.trim()).filter(Boolean),
      disputes: editingRule?.disputes || 0,
    };
    if (!next.id || !next.type || !next.text) { notify('Rule ID, type, and guidance are required.'); return; }
    if (workspace.rules.some(rule => rule.id === next.id && rule.id !== editingRule?.id)) { notify('That rule ID is already in use.'); return; }
    save({ rules: editingRule ? workspace.rules.map(rule => rule.id === editingRule.id ? next : rule) : [next, ...workspace.rules] },
      editingRule ? 'Rule updated' : 'Rule created', next.id);
    setDialog(null); setEditingRule(null); notify(editingRule ? 'Canon rule updated.' : 'Canon rule created.');
  };
  const deleteRule = (rule: Rule) => {
    if (!window.confirm(`Delete rule ${rule.id}? Existing review history will remain unchanged.`)) return;
    save({ rules: workspace.rules.filter(item => item.id !== rule.id) }, 'Rule deleted', rule.id);
    notify('Rule deleted.');
  };
  const exportJson = () => downloadFile('canon-workspace.json', JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), ...workspace }, null, 2), 'application/json');
  const exportCsv = () => {
    const esc = (value: string) => `"${value.replaceAll('"', '""')}"`;
    const rows = [['id', 'type', 'text', 'owner', 'status', 'expiry', 'applies', 'disputes'], ...workspace.rules.map(r => [r.id,r.type,r.text,r.owner,r.status,r.expiry || '',r.applies.join('; '),String(r.disputes)])];
    downloadFile('canon-rules.csv', rows.map(row => row.map(esc).join(',')).join('\n'), 'text/csv');
  };
  const importWorkspace = () => {
    try {
      const parsed = JSON.parse(importText) as Partial<Workspace>;
      if (!Array.isArray(parsed.rules) || !Array.isArray(parsed.reviews) || !Array.isArray(parsed.audit)) throw new Error('This file is not a complete CANON workspace export.');
      if (!window.confirm('Replace the current browser workspace with this imported data?')) return;
      const role = roles.includes(parsed.role as Role) ? parsed.role as Role : workspace.role;
      setWorkspace({ rules: parsed.rules, reviews: parsed.reviews, audit: parsed.audit, role, settings: { ...initialSettings, ...parsed.settings } });
      setDialog(null); setImportText(''); notify('Workspace imported into this browser.');
    } catch (error) { notify(error instanceof Error ? error.message : 'Could not import workspace.'); }
  };
  const resetWorkspace = () => {
    if (!window.confirm('Reset this browser workspace? Rules, reviews, history, audit log, role, and settings will be removed. This cannot be undone.')) return;
    localStorage.removeItem(STORE_KEY);
    const fresh = { rules: starterRules, reviews: [], audit: [], role: 'Creator' as Role, settings: initialSettings };
    setWorkspace(fresh); setDialog(null); setActiveReviewId(null); setDraftText(''); setAttachments([]); setAttachmentNames([]);
    notify('Workspace reset to the original demo rules.');
  };
  const downloadReport = (item: ReviewItem) => {
    const body = [
      `# CANON review — ${item.title}`, '', `Status: ${item.status}`, `Created: ${new Date(item.createdAt).toLocaleString()}`,
      '', '## Summary', item.summary, '', '## Draft', item.draft, '', '## Findings',
      ...(item.findings.length ? item.findings.flatMap(f => [`### ${f.severity} · ${f.category}`, `Rule: ${f.ruleId}`, `Status: ${f.status}`, `Quote: “${f.quote}”`, `Suggestion: ${f.suggestion}`, `Why: ${f.explanation}`, '']) : ['No findings were returned for this review.']),
      '', `Attachments: ${item.attachmentNames.length ? item.attachmentNames.join(', ') : 'None'}`, '',
      'This report reflects a browser-local demo workspace. AI review requires an internet connection.',
    ].join('\n');
    downloadFile(`canon-review-${item.id.slice(0, 8)}.md`, body, 'text/markdown');
  };
  const shareReview = async (item: ReviewItem) => {
    const text = `CANON review: ${item.title}\nStatus: ${item.status}\n${item.summary}\n${item.findings.length} finding(s)`;
    try {
      if (navigator.share) await navigator.share({ title: `CANON review — ${item.title}`, text, url: window.location.href });
      else { await navigator.clipboard.writeText(text); notify('Review summary copied.'); }
    } catch (error) { if (!(error instanceof Error && error.name === 'AbortError')) notify('Could not share this review.'); }
  };
  const copyAppUrl = async () => {
    try { await navigator.clipboard.writeText(window.location.href); notify('App URL copied. It opens this workspace on the current device only.'); }
    catch { notify('Clipboard access is not available in this browser.'); }
  };
  const importFile = async (file: File) => { setImportText(await file.text()); setDialog('import'); };
  const filteredRules = workspace.rules.filter(r => (ruleFilter === 'all' || r.status === ruleFilter) && `${r.id} ${r.type} ${r.text} ${r.owner}`.toLowerCase().includes(ruleSearch.toLowerCase()));
  const filteredQueue = workspace.reviews.filter(item => (queueFilter === 'all' || (queueFilter === 'pending' ? item.status === 'queued' : item.status === queueFilter)) && `${item.title} ${item.draft}`.toLowerCase().includes(queueSearch.toLowerCase()));

  const onNav = (href: string) => setLocation(href);
  return (
    <div className="app-shell" data-tips={workspace.settings.showTips} data-compact={workspace.settings.compact}>
      <aside className="side-rail">
        <Link href="/" className="brand-lockup" aria-label="CANON overview">
          <div className="brand-mark">C</div><div><div className="brand-name">CANON</div><div className="brand-caption">Brand governance</div></div>
        </Link>
        <div className="nav-label">Workspace</div>
        <nav className="nav-list" aria-label="Primary navigation">
          {routes.map(({ href, title, icon: Icon }) => <Link href={href} key={href} className={`nav-link ${path === href ? 'active' : ''}`} data-testid={`link-nav-${title.toLowerCase().replaceAll(' ', '-')}`}><Icon aria-hidden="true"/><span>{title}</span></Link>)}
        </nav>
        <div className="rail-bottom">
          <div className="storage-card"><div className="storage-title"><LockKeyhole/> Saved on this browser</div><p>Rules and review history stay on this device. They do not sync to other browsers.</p></div>
          <div className="rail-user"><div className="avatar">{workspace.role.slice(0,1)}</div><div><div className="rail-role">{workspace.role}</div><div className="rail-demo">Demo mode · not sign-in</div></div></div>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="crumb">{path === '/' ? 'Workspace / Overview' : `Workspace / ${path.slice(1).replace('-', ' ')}`}</div>
          <div className="top-actions">
            <span className="demo-pill">Demo mode</span>
            <label className="sr-only" htmlFor="role-picker">Choose demo role</label>
            <select id="role-picker" className="role-select" aria-label="Choose demo role" value={workspace.role} onChange={e => setRole(e.target.value as Role)} data-testid="select-demo-role">
              {roles.map(role => <option key={role}>{role}</option>)}
            </select>
            <button className="icon-button" type="button" aria-label="Copy app URL" title="Copy app URL" onClick={copyAppUrl} data-testid="button-copy-url"><Copy/></button>
          </div>
        </header>
        <Switch>
          <Route path="/">
            <Dashboard workspace={workspace} onNav={onNav} onReport={downloadReport}/>
          </Route>
          <Route path="/review">
            <ReviewPage draftText={draftText} setDraftText={setDraftText} draftTitle={draftTitle} setDraftTitle={setDraftTitle}
              attachments={attachments} attachmentNames={attachmentNames} onFiles={addFiles} onRemoveFile={index => { setAttachments(a => a.filter((_, i) => i !== index)); setAttachmentNames(a => a.filter((_, i) => i !== index)); }}
              fileInput={fileInput} onAnalyze={handleAnalyze} mutation={mutation} activeRules={activeRules.length} selectedReview={selectedReview}
              reviews={workspace.reviews} onSelectReview={setActiveReviewId} onFindingStatus={acceptFinding} role={workspace.role} onSubmit={submitToQueue}
              onReport={downloadReport} onShare={shareReview}/>
          </Route>
          <Route path="/guidelines">
            <Guidelines rules={filteredRules} search={ruleSearch} setSearch={setRuleSearch} filter={ruleFilter} setFilter={setRuleFilter}
              canManage={canManage} onCreate={() => { setEditingRule(null); setDialog('rule'); }} onEdit={rule => { setEditingRule(rule); setDialog('rule'); }}
              onDelete={deleteRule} onExport={exportCsv}/>
          </Route>
          <Route path="/queue">
            <QueuePage items={filteredQueue} search={queueSearch} setSearch={setQueueSearch} filter={queueFilter} setFilter={setQueueFilter}
              canReview={canReview} onDecision={decideReview} onReport={downloadReport} onInspect={id => { setActiveReviewId(id); setLocation('/review'); }} onGoReview={() => setLocation('/review')}/>
          </Route>
          <Route path="/insights"><Insights workspace={workspace}/></Route>
          <Route path="/settings">
            <SettingsPage workspace={workspace} onExport={exportJson} onCsv={exportCsv} onImportClick={() => importInput.current?.click()}
              importInput={importInput} onImportFile={importFile} onReset={() => setDialog('reset')} activeTab={settingsTab} installReady={installReady} onInstall={requestInstall}
              setActiveTab={setSettingsTab} onSettings={settings => save({ settings }, 'Settings updated', 'Workspace preferences changed')}/>
          </Route>
          <Route component={NotFound}/>
        </Switch>
      </main>
      {dialog === 'rule' && <RuleDialog rule={editingRule} onClose={() => { setDialog(null); setEditingRule(null); }} onSubmit={saveRule}/>}
      {dialog === 'import' && <Dialog title="Import workspace" subtitle="Replace the data saved in this browser." onClose={() => setDialog(null)}>
        <label className="field-label" htmlFor="import-json">Workspace JSON</label><textarea id="import-json" className="field-textarea" value={importText} onChange={e => setImportText(e.target.value)} placeholder="Paste a CANON workspace export…" />
        <p className="field-hint">Import replaces your current local rules, reviews, audit log, role, and settings.</p>
        <div className="dialog-foot"><button className="button button-secondary" onClick={() => setDialog(null)}>Cancel</button><button className="button button-primary" onClick={importWorkspace}>Replace workspace</button></div>
      </Dialog>}
      {dialog === 'reset' && <Dialog title="Reset this workspace?" subtitle="This affects only the workspace saved in this browser." onClose={() => setDialog(null)}>
        <div className="network-note"><AlertCircle/> This permanently clears your rules, review history, reviewer queue, audit log, role, and settings from this browser. Export a backup first if needed.</div>
        <div className="dialog-foot"><button className="button button-secondary" onClick={() => setDialog(null)}>Keep workspace</button><button className="button button-danger" onClick={resetWorkspace}>Reset workspace</button></div>
      </Dialog>}
      {toast && <div className="toast" role="status" data-testid="status-toast">{toast}</div>}
    </div>
  );
}

function downloadFile(name: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = name; anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function Dashboard({ workspace, onNav, onReport }: { workspace: Workspace; onNav: (href: string) => void; onReport: (item: ReviewItem) => void }) {
  const active = workspace.rules.filter(r => r.status === 'active').length;
  const queued = workspace.reviews.filter(r => r.status === 'queued').length;
  const findings = workspace.reviews.reduce((sum, item) => sum + item.findings.length, 0);
  const unresolved = workspace.reviews.reduce((sum, item) => sum + item.findings.filter(f => f.status === 'open').length, 0);
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Brand source of truth</div><h1>Good work, on brand.</h1><p className="page-subtitle">A clear, explainable workspace for the people shaping and protecting your brand.</p></div><button className="button button-primary" onClick={() => onNav('/review')} data-testid="button-start-review"><Plus/> Review a draft <ArrowRight/></button></div>
    <div className="stat-grid">
      <Stat label="Active Canon rules" value={active} foot="Rules included in new reviews" icon={<BookOpen/>}/>
      <Stat label="Awaiting review" value={queued} foot="Drafts in the reviewer queue" icon={<Inbox/>}/>
      <Stat label="Reviews completed" value={workspace.reviews.length} foot="Stored on this browser" icon={<ClipboardCheck/>}/>
      <Stat label="Open findings" value={unresolved} foot={`${findings} total findings across reviews`} icon={<ShieldCheck/>}/>
    </div>
    <div className="dash-grid">
      <section className="panel">
        <div className="panel-head"><div><h2 className="panel-title">Recent activity</h2><p className="panel-note">The local record of governance decisions.</p></div><Link href="/insights" className="button button-quiet button-small">View insights <ArrowRight/></Link></div>
        <div className="panel-body">
          {workspace.audit.length ? workspace.audit.slice(0, 5).map(event => <div className="activity-row" key={event.id}>
            <div className="activity-icon"><History/></div><div className="activity-main"><div className="activity-title">{event.action}</div><div className="activity-meta">{event.detail || 'Workspace updated'} · {new Date(event.at).toLocaleString()}</div></div><span className="activity-tag">{event.actor}</span>
          </div>) : <Empty icon={<History/>} title="A clean slate" copy="Reviews, rule changes, and decisions will appear here as you work." action="Review your first draft" onAction={() => onNav('/review')}/>}
        </div>
      </section>
      <section className="panel">
        <div className="panel-head"><div><h2 className="panel-title">Your recent reviews</h2><p className="panel-note">Explainable, rule-cited, and saved locally.</p></div><Link href="/review" className="button button-quiet button-small">All reviews <ArrowRight/></Link></div>
        <div className="panel-body">
          {workspace.reviews.length ? workspace.reviews.slice(0, 4).map(item => <div className="activity-row" key={item.id}>
            <div className="activity-icon"><FileText/></div><div className="activity-main"><div className="activity-title">{item.title}</div><div className="activity-meta">{item.findings.length} findings · {new Date(item.createdAt).toLocaleDateString()}</div></div><button className="icon-button" aria-label={`Download report for ${item.title}`} onClick={() => onReport(item)}><Download/></button>
          </div>) : <Empty icon={<ClipboardCheck/>} title="Nothing reviewed yet" copy="Start with a draft. CANON will compare it against active rules and explain each finding." action="Analyze a draft" onAction={() => onNav('/review')}/>}
        </div>
      </section>
    </div>
    <div className="network-note"><Info/> Workspace data is saved in this browser only. AI analysis requires an internet connection; offline, you can still view and manage locally saved data.</div>
  </div>;
}

function Stat({ label, value, foot, icon }: { label: string; value: number; foot: string; icon: ReactNode }) {
  return <div className="panel stat-card"><div className="stat-label">{label}</div><div className="stat-number">{value}</div><div className="stat-foot">{foot}</div><div className="stat-spark">{icon}</div></div>;
}
function Empty({ icon, title, copy, action, onAction }: { icon: ReactNode; title: string; copy: string; action?: string; onAction?: () => void }) {
  return <div className="empty-state"><div className="empty-mark">{icon}</div><h3 className="empty-title">{title}</h3><p className="empty-copy">{copy}</p>{action && onAction && <button className="button button-secondary button-small" onClick={onAction}>{action} <ArrowRight/></button>}</div>;
}

function ReviewPage(props: {
  draftText: string; setDraftText: (text: string) => void; draftTitle: string; setDraftTitle: (title: string) => void;
  attachments: CanonAttachment[]; attachmentNames: string[]; onFiles: (files: FileList | null) => void;
  onRemoveFile: (index: number) => void; fileInput: RefObject<HTMLInputElement | null>; onAnalyze: () => void;
  mutation: ReturnType<typeof useAnalyzeCanonDraft>; activeRules: number; selectedReview: ReviewItem | null;
  reviews: ReviewItem[]; onSelectReview: (id: string) => void; onFindingStatus: (reviewId: string, findingId: string, status: FindingStatus) => void;
  role: Role; onSubmit: (id: string) => void; onReport: (item: ReviewItem) => void; onShare: (item: ReviewItem) => void;
}) {
  const { draftText,setDraftText,draftTitle,setDraftTitle,attachments,attachmentNames,onFiles,onRemoveFile,fileInput,onAnalyze,mutation,activeRules,selectedReview,reviews,onSelectReview,onFindingStatus,role,onSubmit,onReport,onShare } = props;
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Draft analysis</div><h1>Review a draft.</h1><p className="page-subtitle">Get specific guidance grounded in the active Canon rules. Every finding includes its reason and a path forward.</p></div></div>
    <div className="review-layout">
      <section className="panel review-form">
        <div className="form-block"><label className="field-label" htmlFor="draft-title">Draft name <span style={{color:'#8c9088',fontWeight:400}}>— optional</span></label><input id="draft-title" className="field-input" value={draftTitle} onChange={e => setDraftTitle(e.target.value)} placeholder="e.g. Spring launch caption" maxLength={100} data-testid="input-draft-title"/></div>
        <div className="form-block"><label className="field-label" htmlFor="draft-text">Content to review</label><textarea id="draft-text" className="field-textarea" value={draftText} onChange={e => setDraftText(e.target.value)} maxLength={40000} placeholder="Paste campaign copy, a social caption, product language, or other brand content…" data-testid="input-draft-text"/><div className="field-hint">{draftText.length.toLocaleString()} / 40,000 characters</div></div>
        <div className="form-block">
          <div className="field-label">Supporting files <span style={{fontWeight:400,color:'#858982'}}>— optional</span></div>
          <div className="attachment-box"><div className="attachment-copy"><Paperclip/><div><div className="attachment-title">Add source material</div><div className="attachment-sub">PDF, PNG, JPEG, WebP, or GIF · up to 5 files · combined 4 MB</div></div></div><button className="button button-secondary button-small" onClick={() => fileInput.current?.click()} disabled={attachments.length >= MAX_ATTACHMENTS}><Upload/> Choose files</button><input ref={fileInput} hidden type="file" accept=".pdf,image/png,image/jpeg,image/webp,image/gif" multiple onChange={e => { onFiles(e.currentTarget.files); e.currentTarget.value = ''; }}/></div>
          {!!attachmentNames.length && <div className="file-pills">{attachmentNames.map((name,index)=><div className="file-pill" key={`${name}-${index}`}><Paperclip/>{name}<button aria-label={`Remove ${name}`} onClick={() => onRemoveFile(index)}><X/></button></div>)}</div>}
        </div>
        <div className="network-note"><CloudOff/> Draft text and selected files are sent to Google Gemini for analysis using the server-stored key. Your local workspace does not sync between browsers.</div>
        <button className="button button-primary" onClick={onAnalyze} disabled={mutation.isPending || !activeRules} data-testid="button-analyze">{mutation.isPending ? <><span className="skeleton" style={{width:14,height:14,borderRadius:'50%'}}/> Comparing with active rules…</> : <><ShieldCheck/> Analyze against {activeRules} active rules <ArrowRight/></>}</button>
        {!activeRules && <p className="field-hint">No active Canon rules are available. A Brand Admin can activate rules in Guidelines.</p>}
        {mutation.isError && <div className="error-box" style={{marginTop:14}} role="alert"><strong>Review could not be completed</strong>{getErrorMessage(mutation.error)} Your draft remains in this form. Check your connection and try again.</div>}
      </section>
      <section className="panel result-panel">
        <div className="panel-head"><div><h2 className="panel-title">Review findings</h2><p className="panel-note">Evidence and guidance, not an opaque score.</p></div>{selectedReview && <div className="report-tools"><button className="icon-button" title="Download Markdown report" aria-label="Download Markdown report" onClick={() => onReport(selectedReview)}><Download/></button><button className="icon-button" title="Share review summary" aria-label="Share review summary" onClick={() => onShare(selectedReview)}><Copy/></button></div>}</div>
        {mutation.isPending ? <div className="loading-lines"><div className="skeleton" style={{width:'42%'}}/><div className="skeleton" style={{width:'90%'}}/><div className="skeleton" style={{width:'77%',height:74}}/><div className="skeleton" style={{width:'88%',height:74}}/></div> :
          selectedReview ? <div className="panel-body">
            <div className="rule-meta"><span className={`badge ${selectedReview.status === 'rejected' ? 'rejected' : selectedReview.status === 'queued' ? 'pending' : ''}`}>{selectedReview.status}</span><span className="rule-id">{selectedReview.findings.length} finding{selectedReview.findings.length === 1 ? '' : 's'}</span></div>
            <p className="result-summary">{selectedReview.summary}</p>
            {selectedReview.findings.length ? selectedReview.findings.map(f => <FindingCard key={f.id} finding={f} onStatus={status => onFindingStatus(selectedReview.id, f.id, status)}/>) :
              <div className="network-note"><CheckCircle2/> No findings were returned for this analysis. This is the service’s result, not a substitute for human review.</div>}
            {(selectedReview.status === 'draft' || selectedReview.status === 'rejected') && role === 'Creator' && <button className="button button-primary" onClick={() => onSubmit(selectedReview.id)}><Inbox/> {selectedReview.status === 'rejected' ? 'Resubmit to reviewer queue' : 'Submit to reviewer queue'}</button>}
            <div className="field-hint">Reviewed {new Date(selectedReview.createdAt).toLocaleString()} · {selectedReview.attachmentNames.length ? selectedReview.attachmentNames.join(', ') : 'No attachments'}</div>
          </div> : <Empty icon={<ShieldCheck/>} title="Ready when you are" copy="Submit a draft to see rule-cited findings, quoted evidence, and suggested language. No review results are invented or cached as examples."/>}
        {selectedReview && <div style={{padding:'0 20px 16px',borderTop:'1px solid hsl(var(--border))',paddingTop:12}}>
          <div className="field-label">Recent workspace reviews</div>{/* Select an actual persisted review */}
          <select className="field-select" aria-label="Select a saved review" value={selectedReview.id} onChange={e => onSelectReview(e.target.value)}>
            {reviews.map(review => <option key={review.id} value={review.id}>{review.title} · {review.status}</option>)}
          </select>
        </div>}
      </section>
    </div>
  </div>;
}
function getErrorMessage(error: unknown) {
  if (error && typeof error === 'object' && 'data' in error) {
    const data = (error as {data?: unknown}).data;
    if (data && typeof data === 'object' && 'error' in data && typeof data.error === 'string') return data.error;
  }
  if (error && typeof error === 'object' && 'message' in error) return String((error as {message?: unknown}).message || 'The analysis service returned an error.');
  return 'The analysis service returned an error.';
}
function FindingCard({ finding, onStatus }: { finding: Finding; onStatus: (status: FindingStatus) => void }) {
  return <article className="finding" data-testid={`finding-card-${finding.id}`}>
    <div className="finding-top"><span className={`badge ${finding.severity.toLowerCase()}`}>{finding.severity}</span><span className="finding-category">{finding.category}</span><span className="rule-id">Rule {finding.ruleId}</span></div>
    <div className="finding-quote">“{finding.quote}”</div>
    <p className="finding-explanation">{finding.explanation}</p>
    <p className="finding-suggestion"><strong>Try instead:</strong> {finding.suggestion}</p>
    <div className="finding-actions"><button className={`finding-action ${finding.status === 'accepted' ? 'selected' : ''}`} aria-pressed={finding.status === 'accepted'} onClick={() => onStatus(finding.status === 'accepted' ? 'open' : 'accepted')}><Check/> Accept guidance</button><button className={`finding-action disputed ${finding.status === 'disputed' ? 'selected' : ''}`} aria-pressed={finding.status === 'disputed'} onClick={() => onStatus(finding.status === 'disputed' ? 'open' : 'disputed')}><CircleHelp/> Dispute</button></div>
  </article>;
}

function Guidelines({ rules, search, setSearch, filter, setFilter, canManage, onCreate, onEdit, onDelete, onExport }: {
  rules: Rule[]; search: string; setSearch: (value: string) => void; filter: string; setFilter: (value: string) => void; canManage: boolean;
  onCreate: () => void; onEdit: (rule: Rule) => void; onDelete: (rule: Rule) => void; onExport: () => void;
}) {
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Shared standards</div><h1>Canon rules.</h1><p className="page-subtitle">The principles CANON cites when reviewing content. Only active rules are sent for analysis.</p></div><div className="report-tools"><button className="button button-secondary" onClick={onExport}><Download/> Export CSV</button>{canManage && <button className="button button-primary" onClick={onCreate} data-testid="button-create-rule"><Plus/> New rule</button>}</div></div>
    {!canManage && <div className="network-note"><LockKeyhole/> Rule changes are reserved for Brand Admin. Switch the demo role in the header to explore rule management.</div>}
    <div className="rule-toolbar"><div className="search-wrap"><Search/><input className="search-input" placeholder="Search by rule, type, owner…" aria-label="Search rules" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-rule-search"/></div><select className="select-filter" aria-label="Filter rules by status" value={filter} onChange={e => setFilter(e.target.value)}><option value="all">All statuses</option><option value="active">Active</option><option value="draft">Draft</option><option value="archived">Archived</option></select><span className="field-hint" style={{margin:0}}>{rules.length} rule{rules.length === 1 ? '' : 's'}</span></div>
    <div className="panel">
      {rules.length ? <div className="rule-list">{rules.map(rule => <div className="rule-row" key={rule.id} data-testid={`rule-row-${rule.id}`}>
        <div><div className="rule-meta"><span className="rule-id">{rule.id}</span><span className="badge">{rule.type}</span><span className={`badge ${rule.status !== 'active' ? 'pending' : ''}`}>{rule.status}</span></div><p className="rule-text">{rule.text}</p><div className="rule-detail">Owner: {rule.owner} · Applies to: {rule.applies.join(', ') || 'All content'}{rule.expiry ? ` · Expires ${rule.expiry}` : ''} · {rule.disputes} dispute{rule.disputes === 1 ? '' : 's'}</div></div>
        {canManage && <div className="row-actions"><button className="icon-button" aria-label={`Edit ${rule.id}`} title="Edit rule" onClick={() => onEdit(rule)}><MoreHorizontal/></button><button className="icon-button" aria-label={`Delete ${rule.id}`} title="Delete rule" onClick={() => onDelete(rule)}><Trash2/></button></div>}
      </div>)}</div> : <Empty icon={<BookOpen/>} title={search ? 'No matching rules' : 'No rules in this view'} copy={search ? 'Try another search term or clear your filters.' : 'A Brand Admin can add a Canon rule to begin building the source of truth.'} action={canManage ? 'Create a rule' : undefined} onAction={canManage ? onCreate : undefined}/>}
    </div>
    <p className="field-hint" style={{marginTop:12}}>Rules and changes are stored in this browser only. Export a workspace backup to move them elsewhere.</p>
  </div>;
}

function QueuePage({ items, search, setSearch, filter, setFilter, canReview, onDecision, onReport, onInspect, onGoReview }: {
  items: ReviewItem[]; search: string; setSearch: (value:string)=>void; filter:string; setFilter:(value:string)=>void;
  canReview:boolean; onDecision:(id:string,status:'approved'|'rejected')=>void; onReport:(item:ReviewItem)=>void; onInspect:(id:string)=>void; onGoReview:()=>void;
}) {
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Human judgment</div><h1>Review queue.</h1><p className="page-subtitle">A reviewer makes the call. AI findings are evidence to consider, never an automatic approval.</p></div><span className="demo-pill">{items.filter(i => i.status === 'queued').length} awaiting</span></div>
    {!canReview && <div className="network-note"><LockKeyhole/> Creator role can submit drafts, but only Reviewer or Brand Admin can approve or return them.</div>}
    <div className="rule-toolbar"><div className="search-wrap"><Search/><input className="search-input" placeholder="Search draft names or content…" aria-label="Search queue" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-queue-search"/></div><select className="select-filter" aria-label="Filter queue" value={filter} onChange={e=>setFilter(e.target.value)}><option value="pending">Awaiting review</option><option value="all">All reviews</option><option value="approved">Approved</option><option value="rejected">Returned</option><option value="draft">Creator drafts</option></select></div>
    <div className="panel">
      {items.length ? items.map(item => <article className="queue-item" key={item.id} data-testid={`queue-item-${item.id}`}>
        <div className="queue-top"><h2 className="queue-title">{item.title}</h2><div className="rule-meta"><span className={`badge ${item.status === 'queued' ? 'pending' : item.status === 'rejected' ? 'rejected' : ''}`}>{item.status}</span><span className="badge">{item.findings.length} findings</span></div></div>
        <p className="queue-excerpt">{item.summary}<br/><span>{item.draft.length > 220 ? `${item.draft.slice(0,220)}…` : item.draft}</span></p>
        <div className="queue-footer"><span className="activity-meta">{new Date(item.updatedAt).toLocaleString()} · {item.attachmentNames.length} attachment{item.attachmentNames.length === 1 ? '' : 's'}</span><div className="queue-actions"><button className="button button-secondary button-small" onClick={() => onInspect(item.id)}><FileText/> Inspect findings</button><button className="icon-button" aria-label="Download review report" onClick={() => onReport(item)}><Download/></button>{item.status === 'queued' && canReview && <><button className="button button-secondary button-small" onClick={() => onDecision(item.id, 'rejected')}><XCircle/> Return</button><button className="button button-primary button-small" onClick={() => onDecision(item.id, 'approved')}><CheckCircle2/> Approve</button></>}</div></div>
      </article>) : <Empty icon={<Inbox/>} title={search ? 'No drafts found' : 'The queue is clear'} copy={search ? 'Try a different search or filter.' : 'When a creator submits a reviewed draft, it will appear here for human approval.'} action="Go to draft review" onAction={onGoReview}/>}
    </div>
  </div>;
}

function Insights({ workspace }: { workspace: Workspace }) {
  const rules = workspace.rules;
  const allFindings = workspace.reviews.flatMap(review => review.findings);
  const disputesByRule = new Map<string, number>();
  allFindings.filter(f => f.status === 'disputed').forEach(f => disputesByRule.set(f.ruleId, (disputesByRule.get(f.ruleId) || 0) + 1));
  const ranked = rules.map(rule => ({ rule, disputes: Math.max(rule.disputes, disputesByRule.get(rule.id) || 0) })).sort((a,b) => b.disputes - a.disputes);
  const severityCount = ['HIGH','MEDIUM','LOW'].map(level => ({label:level, count:allFindings.filter(f => f.severity === level).length}));
  const decided = workspace.reviews.filter(r => r.status === 'approved' || r.status === 'rejected').length;
  const approvalPct = decided ? Math.round(workspace.reviews.filter(r => r.status === 'approved').length / decided * 100) : 0;
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Governance signals</div><h1>Clarity, over time.</h1><p className="page-subtitle">Use repeated disputes and reviewer decisions to find where guidance needs to be clearer. Local data only; no activity is fabricated.</p></div></div>
    <div className="stat-grid"><Stat label="Drafts analyzed" value={workspace.reviews.length} foot="Reviews stored in this browser" icon={<FileText/>}/><Stat label="Findings returned" value={allFindings.length} foot="From real analysis responses" icon={<Shield/>}/><Stat label="Human approval rate" value={approvalPct} foot={decided ? `Across ${decided} reviewer decisions` : 'Available after reviewer decisions'} icon={<CheckCircle2/>}/><Stat label="Disputed findings" value={allFindings.filter(f=>f.status==='disputed').length} foot="Disagreements worth discussing" icon={<CircleHelp/>}/></div>
    <div className="dash-grid">
      <section className="panel"><div className="panel-head"><div><h2 className="panel-title">Rules drawing questions</h2><p className="panel-note">Rules with the most reported disputes.</p></div></div><div className="panel-body">
        {ranked.some(item => item.disputes > 0) ? <div className="bars">{ranked.slice(0,7).map(({rule,disputes})=><div className="bar-row" key={rule.id}><div className="bar-label">{rule.id} · {rule.type}</div><div className="bar-track"><div className="bar-fill" style={{width:`${Math.min(100,disputes / Math.max(1,ranked[0].disputes) * 100)}%`}}/></div><div className="bar-value">{disputes}</div></div>)}</div> : <Empty icon={<Activity/>} title="No governance signals yet" copy="As findings are accepted or disputed, patterns will surface here."/>}
        <div className="metric-callout"><div><h3>Ambiguity is a design input.</h3><p>Repeated disputes can point to unclear language, conflicting context, or an edge case worth bringing to a reviewer.</p></div><div className="metric-number">{allFindings.filter(f=>f.status==='disputed').length}</div></div>
      </div></section>
      <section className="panel"><div className="panel-head"><div><h2 className="panel-title">Finding severity</h2><p className="panel-note">Only findings returned by the analysis service.</p></div></div><div className="panel-body">{severityCount.some(x=>x.count) ? <div className="bars">{severityCount.map(({label,count})=><div className="bar-row" key={label}><div className="bar-label">{label}</div><div className="bar-track"><div className="bar-fill" style={{width:`${allFindings.length ? count/allFindings.length*100 : 0}%`}}/></div><div className="bar-value">{count}</div></div>)}</div> : <Empty icon={<ShieldCheck/>} title="Waiting on reviews" copy="Severity distribution appears after real draft analysis results are saved."/>}</div></section>
    </div>
    <section className="panel" style={{marginTop:15}}><div className="panel-head"><div><h2 className="panel-title">Governance audit log</h2><p className="panel-note">A browser-local record of meaningful changes and decisions.</p></div><span className="rule-id">{workspace.audit.length} events</span></div><div className="panel-body">
      {workspace.audit.length ? workspace.audit.slice(0,12).map(event=><div className="audit-line" key={event.id}><div className="audit-time">{new Date(event.at).toLocaleString()}</div><div className="audit-event"><strong>{event.action}</strong> · {event.detail || 'Workspace updated'}</div><div className="audit-actor">{event.actor}</div></div>) : <Empty icon={<History/>} title="No audit events yet" copy="Rule changes, review decisions, and workspace actions will be recorded here."/>}
    </div></section>
  </div>;
}

function SettingsPage({ workspace,onExport,onCsv,onImportClick,importInput,onImportFile,onReset,activeTab,setActiveTab,onSettings,installReady,onInstall }: {
  workspace:Workspace;onExport:()=>void;onCsv:()=>void;onImportClick:()=>void;importInput:RefObject<HTMLInputElement|null>;
  onImportFile:(file:File)=>void;onReset:()=>void;activeTab:string;setActiveTab:(tab:string)=>void;onSettings:(settings:SettingsData)=>void;
  installReady:boolean;onInstall:()=>void;
}) {
  const set = (patch: Partial<SettingsData>)=>onSettings({...workspace.settings,...patch});
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Workspace controls</div><h1>Settings.</h1><p className="page-subtitle">Manage this browser’s CANON workspace and your preferences. Demo roles are a preview, not authentication.</p></div></div>
    <div className="settings-grid">
      <div className="panel settings-nav">{['Preferences','Data & privacy','About CANON'].map(tab=><button className={activeTab===tab?'active':''} key={tab} onClick={()=>setActiveTab(tab)}>{tab}</button>)}</div>
      <div>
        {activeTab==='Preferences' && <section className="panel settings-section"><h3>Preferences</h3><p>Make this workspace comfortable to use.</p>
          <div className="settings-row"><div><div className="settings-row-title">Dark appearance</div><div className="settings-row-copy">Use a low-light palette for this browser workspace.</div></div><Toggle checked={workspace.settings.colorMode==='dark'} onChange={checked=>set({colorMode:checked?'dark':'light'})}/></div>
          <div className="settings-row"><div><div className="settings-row-title">Compact layout</div><div className="settings-row-copy">Reduce row spacing in longer lists.</div></div><Toggle checked={workspace.settings.compact} onChange={checked=>set({compact:checked})}/></div>
          <div className="settings-row"><div><div className="settings-row-title">Context tips</div><div className="settings-row-copy">Show notes about local storage, reviewer roles, and analysis.</div></div><Toggle checked={workspace.settings.showTips} onChange={checked=>set({showTips:checked})}/></div>
        </section>}
        {activeTab==='Data & privacy' && <section className="panel settings-section"><h3>Data & privacy</h3><p>Your workspace is stored in this browser’s local storage and does not synchronize across devices. Submitted drafts and attachments are sent to Google Gemini for AI review using the key configured for this project. The key stays on the server; Gemini API usage follows the billing settings of the account that owns it.</p>
          <div className="settings-row"><div><div className="settings-row-title">Export full workspace</div><div className="settings-row-copy">Download rules, reviews, queue, audit log, role, and settings as JSON.</div></div><button className="button button-secondary button-small" onClick={onExport}><Download/> Download JSON</button></div>
          <div className="settings-row"><div><div className="settings-row-title">Import workspace backup</div><div className="settings-row-copy">Replace this browser’s data with a previous CANON JSON export.</div></div><button className="button button-secondary button-small" onClick={onImportClick}><Upload/> Import JSON</button><input hidden ref={importInput} type="file" accept=".json,application/json" onChange={e=>{if(e.target.files?.[0])onImportFile(e.target.files[0]);e.target.value='';}}/></div>
          <div className="settings-row"><div><div className="settings-row-title">Export Canon rules</div><div className="settings-row-copy">A portable CSV for sharing a snapshot of your rule set.</div></div><button className="button button-secondary button-small" onClick={onCsv}><Download/> Download CSV</button></div>
          <div className="settings-row"><div><div className="settings-row-title">Reset workspace</div><div className="settings-row-copy">Clear local data and restore the original demo rule set.</div></div><button className="button button-danger button-small" onClick={onReset}><Trash2/> Reset data</button></div>
        </section>}
        {activeTab==='About CANON' && <section className="panel settings-section"><h3>Clear rules. Better decisions.</h3><p>CANON is a browser-saved brand governance workspace for creators, reviewers, and brand administrators. It makes the source of truth visible and the reasoning behind findings inspectable.</p><div className="settings-row"><div><div className="settings-row-title">Demo mode</div><div className="settings-row-copy">The role picker switches between Creator, Reviewer, and Brand Admin capabilities. It does not authenticate or establish identity.</div></div><span className="badge pending">Not sign-in</span></div><div className="settings-row"><div><div className="settings-row-title">Offline availability</div><div className="settings-row-copy">The interface and locally saved data remain available offline after installation. AI review requires internet access.</div></div><button className="button button-secondary button-small" onClick={onInstall}>{installReady?'Install app':'How to install'}</button></div></section>}
      </div>
    </div>
  </div>;
}
function Toggle({checked,onChange}:{checked:boolean;onChange:(value:boolean)=>void}) {
  return <button className={`toggle ${checked?'on':''}`} role="switch" aria-checked={checked} onClick={()=>onChange(!checked)}><span/></button>;
}
function Dialog({title,subtitle,onClose,children}:{title:string;subtitle:string;onClose:()=>void;children:ReactNode}) {
  return <div className="dialog-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><header className="dialog-head"><div><h2 id="dialog-title">{title}</h2><p>{subtitle}</p></div><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X/></button></header><div className="dialog-body">{children}</div></section></div>;
}
function RuleDialog({rule,onClose,onSubmit}:{rule:Rule|null;onClose:()=>void;onSubmit:(form:FormData)=>void}) {
  return <Dialog title={rule?'Edit Canon rule':'Add a Canon rule'} subtitle="Write guidance that is specific, readable, and useful in context." onClose={onClose}>
    <form onSubmit={e=>{e.preventDefault();onSubmit(new FormData(e.currentTarget));}}>
      <div className="form-grid">
        <div><label className="field-label" htmlFor="rule-id">Rule ID</label><input required id="rule-id" name="id" className="field-input" defaultValue={rule?.id} maxLength={40} placeholder="VOICE-06"/></div>
        <div><label className="field-label" htmlFor="rule-type">Type</label><input required id="rule-type" name="type" className="field-input" defaultValue={rule?.type} maxLength={80} placeholder="Voice"/></div>
        <div className="wide"><label className="field-label" htmlFor="rule-text">Guidance</label><textarea required id="rule-text" name="text" className="field-textarea" defaultValue={rule?.text} maxLength={3000} placeholder="State the principle clearly. Include boundaries where useful."/></div>
        <div><label className="field-label" htmlFor="rule-owner">Owner</label><input id="rule-owner" name="owner" className="field-input" defaultValue={rule?.owner||'Brand team'} placeholder="Brand team"/></div>
        <div><label className="field-label" htmlFor="rule-status">Status</label><select id="rule-status" name="status" className="field-select" defaultValue={rule?.status||'active'}><option value="active">Active</option><option value="draft">Draft</option><option value="archived">Archived</option></select></div>
        <div><label className="field-label" htmlFor="rule-applies">Applies to</label><input id="rule-applies" name="applies" className="field-input" defaultValue={rule?.applies.join(', ')} placeholder="All content, Social"/></div>
        <div><label className="field-label" htmlFor="rule-expiry">Expiry date</label><input id="rule-expiry" name="expiry" type="date" className="field-input" defaultValue={rule?.expiry}/></div>
      </div>
      <div className="dialog-foot"><button className="button button-secondary" type="button" onClick={onClose}>Cancel</button><button className="button button-primary" type="submit">{rule?'Save changes':'Create rule'}</button></div>
    </form>
  </Dialog>;
}

function Root() {
  return <QueryClientProvider client={queryClient}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><App/></WouterRouter></QueryClientProvider>;
}
export default Root;
