import { createInsertSchema } from "drizzle-zod";
import { pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { canonWorkspacesTable } from "./canon-workspaces";

export const canonApprovedAssetsTable = pgTable("canon_approved_assets", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  fileName: text("file_name").notNull(),
  assetType: text("asset_type").$type<"logo" | "wordmark" | "icon">().notNull(),
  perceptualHash: text("perceptual_hash").notNull(),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCanonApprovedAssetSchema = createInsertSchema(canonApprovedAssetsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertCanonApprovedAsset = z.infer<typeof insertCanonApprovedAssetSchema>;
export type CanonApprovedAsset = typeof canonApprovedAssetsTable.$inferSelect;
