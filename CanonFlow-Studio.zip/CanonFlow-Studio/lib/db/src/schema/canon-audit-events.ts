import { createInsertSchema } from "drizzle-zod";
import { jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { canonWorkspacesTable } from "./canon-workspaces";

export const canonAuditEventsTable = pgTable("canon_audit_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
  actorUserId: text("actor_user_id").notNull(),
  actorRole: text("actor_role").$type<"Brand Admin" | "Reviewer" | "Creator">().notNull(),
  action: text("action").notNull(),
  detail: jsonb("detail").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCanonAuditEventSchema = createInsertSchema(canonAuditEventsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertCanonAuditEvent = z.infer<typeof insertCanonAuditEventSchema>;
export type CanonAuditEvent = typeof canonAuditEventsTable.$inferSelect;
