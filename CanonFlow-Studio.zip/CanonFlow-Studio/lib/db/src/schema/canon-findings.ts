import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { canonReviewsTable } from "./canon-reviews";
import { canonWorkspacesTable } from "./canon-workspaces";

export const canonFindingsTable = pgTable("canon_findings", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
  reviewId: uuid("review_id").notNull().references(() => canonReviewsTable.id, { onDelete: "cascade" }),
  ruleId: text("rule_id").notNull(),
  ruleVersion: integer("rule_version").notNull(),
  severity: text("severity").$type<"HIGH" | "MEDIUM" | "LOW">().notNull(),
  category: text("category").notNull(),
  quote: text("quote").notNull(),
  suggestion: text("suggestion").notNull(),
  explanation: text("explanation").notNull(),
  creatorStatus: text("creator_status").$type<"open" | "accepted" | "disputed">().notNull().default("open"),
  reviewerStatus: text("reviewer_status").$type<"accepted" | "disputed" | null>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCanonFindingSchema = createInsertSchema(canonFindingsTable).omit({
  createdAt: true,
});
export type InsertCanonFinding = z.infer<typeof insertCanonFindingSchema>;
export type CanonFinding = typeof canonFindingsTable.$inferSelect;
