import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { canonWorkspacesTable } from "./canon-workspaces";

export const canonReviewsTable = pgTable(
  "canon_reviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
    creatorUserId: text("creator_user_id").notNull(),
    title: text("title").notNull(),
    draft: text("draft").notNull(),
    summary: text("summary").notNull(),
    status: text("status").$type<"draft" | "queued" | "approved" | "rejected">().notNull().default("draft"),
    attachmentNames: jsonb("attachment_names").$type<string[]>().notNull().default([]),
    canonicalVersion: integer("canonical_version").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("canon_reviews_workspace_id_idx").on(table.workspaceId, table.id)],
);

export const insertCanonReviewSchema = createInsertSchema(canonReviewsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertCanonReview = z.infer<typeof insertCanonReviewSchema>;
export type CanonReview = typeof canonReviewsTable.$inferSelect;
