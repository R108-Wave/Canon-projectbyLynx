import { createInsertSchema } from "drizzle-zod";
import { date, integer, jsonb, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { canonWorkspacesTable } from "./canon-workspaces";

export const canonRulesTable = pgTable(
  "canon_rules",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
    ruleId: text("rule_id").notNull(),
    type: text("type").notNull(),
    text: text("text").notNull(),
    owner: text("owner").notNull(),
    status: text("status").$type<"active" | "draft" | "archived">().notNull().default("active"),
    expiry: date("expiry", { mode: "string" }),
    applies: jsonb("applies").$type<string[]>().notNull().default([]),
    version: integer("version").notNull().default(1),
    createdBy: text("created_by").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("canon_rules_workspace_rule_idx").on(table.workspaceId, table.ruleId)],
);

export const canonRuleVersionsTable = pgTable(
  "canon_rule_versions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
    ruleId: text("rule_id").notNull(),
    version: integer("version").notNull(),
    type: text("type").notNull(),
    text: text("text").notNull(),
    owner: text("owner").notNull(),
    status: text("status").$type<"active" | "draft" | "archived">().notNull(),
    expiry: date("expiry", { mode: "string" }),
    applies: jsonb("applies").$type<string[]>().notNull().default([]),
    actorUserId: text("actor_user_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("canon_rule_versions_workspace_rule_version_idx").on(table.workspaceId, table.ruleId, table.version)],
);

export const insertCanonRuleSchema = createInsertSchema(canonRulesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCanonRule = z.infer<typeof insertCanonRuleSchema>;
export type CanonRule = typeof canonRulesTable.$inferSelect;
export type CanonRuleVersion = typeof canonRuleVersionsTable.$inferSelect;
