import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const canonWorkspacesTable = pgTable(
  "canon_workspaces",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerUserId: text("owner_user_id").notNull().unique(),
    name: text("name").notNull().default("My CANON workspace"),
    canonicalVersion: integer("canonical_version").notNull().default(1),
    revision: integer("revision").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
);

export type CanonWorkspaceSettings = {
  compact: boolean;
  showTips: boolean;
  colorMode: "light" | "dark";
};

export const canonMembersTable = pgTable(
  "canon_members",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id").notNull().references(() => canonWorkspacesTable.id, { onDelete: "cascade" }),
    userId: text("user_id").notNull(),
    role: text("role").$type<"Brand Admin" | "Reviewer" | "Creator">().notNull().default("Creator"),
    settings: jsonb("settings").$type<CanonWorkspaceSettings>().notNull().default({
      compact: false,
      showTips: true,
      colorMode: "light",
    }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("canon_members_workspace_user_idx").on(table.workspaceId, table.userId)],
);

export const insertCanonWorkspaceSchema = createInsertSchema(canonWorkspacesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCanonWorkspace = z.infer<typeof insertCanonWorkspaceSchema>;
export type CanonWorkspace = typeof canonWorkspacesTable.$inferSelect;
export type CanonMember = typeof canonMembersTable.$inferSelect;
